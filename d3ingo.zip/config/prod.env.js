module.exports = {
  VUE_ENV: '"server"',
  NODE_ENV: '"production"',
  API_ROOT: '"http://mc.taihuoniao.com/api"'  // nginx 反向代理
}
