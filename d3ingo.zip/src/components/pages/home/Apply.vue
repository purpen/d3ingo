<template>
  <div class="container">
    <h1>这是申请入驻页</h1>
  </div>
</template>

<script>
export default {
  name: 'test',
  data () {
    return {
      msg: 'This is Home'
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .container{
    height: 500px;
  }
  h1{
    font-size: 60px;
    text-align: center;
    padding-top: 200px;
  }

</style>
