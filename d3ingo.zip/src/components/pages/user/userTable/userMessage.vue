<template>
<div>
  <el-col :span="isMob?24 : 6">
            <div class="input" @click="searchUsername">
              <input type="text" placeholder="搜索成员">
              <img src="../../../../assets/images/member/search02@2x.png" alt="">
            </div>
            <div class="TopUser">
              <router-link :to="{name: 'userAllList'}">成员</router-link> 
              <router-link :to="{name: 'userGroup'}">群组</router-link>
            </div>
             <div class="Alluser">
                <ul>
                  <li class="All" @click="AlluserList">所有成员</li>
                  <li @click="newList">新加入的成员</li>
                  <li @click="NoList">未分配的成员</li>
                  <li @click="stop">常用成员</li>
                </ul>
              </div>
          </el-col>
  <el-col :span="isMob? 24: 18">
        <el-col class="Top">
              <el-col :span="21" class="navText">
                <span>所有成员</span>
                <span>{{20}}</span>
              </el-col>
              <el-col :span="3" class="right">
                <i></i>
                <a @click="alick" class="welcome">邀请成员</a>
              <user :rand_string = "rand_string" :centerDialogVisible="isHide" @alick="alick"></user>
              </el-col>
        </el-col>
        <el-col v-loading.body="isLoading">
          <el-table
            key="withdraw"
            :data="itemList"
            style="width: 100%">
            <el-table-column
              min-width="100"
              prop="realname"
              label="成员名称">
            </el-table-column>
            <el-table-column
              prop=""
              label="">
            </el-table-column>
            <el-table-column
              prop=""
              label="">
            </el-table-column>
            <el-table-column
              prop=""
              label="">
            </el-table-column>
            <el-table-column align="center" label="操作">
              <div slot-scope="props">
                <span class="company">{{props.row.company_role_init}}</span>
                <div class="togger">
                  <img src="../../../../assets/images/member/Group5@2x.png" alt="">
                  <img src="../../../../assets/images/member/small-arrow@2x.png" alt="">
                </div>
              </div>
            </el-table-column>
          </el-table>
        </el-col>
    </el-col>
    </div>
</template>
<script>
import api from '@/api/api'
import user from '@/components/pages/user/Show/UserShow'
export default {
  data () {
    return {
      rand_string: {
        default: ''
      },
      isLoading: false,
      isHide: false,
      itemList: [],
      totalCount: 0
    }
  },
  components: {
    user
  },
  methods: {
    alick() {
      this.$emit('alick')
      this.isHide = !this.isHide
      this.$http.get(api.inviteKey)
          .then((res) => {
            if (res.data.meta.status_code === 200) {
              this.rand_string = `${location.origin}/Invite/${res.data.data.rand_string}`
            } else {
              console.log(res.data.meta.message)
            }
          })
    },
    directOperate (id) {
      this.chooseList = []
      this.chooseList.push(id)
      this.$emit('choose', this.chooseList, '')
    },
    rename(id, index) {
      this.directOperate(id)
      this.$emit('directRename')
      this.renameVal = this.list[index]['name']
    },
    deleteFile(id) {
      this.directOperate(id)
      this.$emit('deleteFile')
    }
  },
  computed: {
    isMob() {
      return this.$store.state.event.isMob
    }
  },
  created: function () {
    const that = this
    // var userid = [that.itemList.id]
    // 获取成员管理
    that.$http.get(api.designMemberList)
        .then(function (response) {
          if (response.data.meta.status_code === 200) {
            that.itemList = response.data.data
            // console.log(that.itemList)
          }
        })
        .catch(function (error) {
          that.$message.error(error.message)
        })
  }
}
</script>
<style scoped>
.navText span {
  font-family: PingFangSC-Regular;
  padding-right: 10px;
  font-size: 16px;
  color: #666666;
  }
  .Top {
    background: #FFFFFF;
    padding-bottom: 20px;
    border-bottom: 1px solid #D2D2D2;
  }
  .Top span {
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #666666;
  }
.right a {
  cursor:pointer;
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #FF5A5F;
  position: absolute;
  left: 29px;
  top: 5px;
}
.right {
  position: relative;
}
.right i{
  display: block;
  height: 24px;
    background: url('../../../../assets/images/member/invitation@2x.png') no-repeat;
    background-size: 24px 24px;
    background-position: left;
}
.Alluser ul{
  width: 280px;
  font-size: 14px;
  cursor: pointer;
}
.Alluser ul li {
  height: 40px;
  line-height: 40px;
  padding-left: 10px;
}
.Alluser ul li:first-child {
  color:#FF5A5F;
  background: #F7F7F7;
}
.Alluser ul li:hover {
  color:#FF5A5F;
  background: #F7F7F7;
}
.input {
  position: relative;
  background: #FFFFFF;
  border: 1px solid #D2D2D2;
  border-radius: 2px;
  margin-bottom: 3px;
}
.TopUser {
  height: 50px;
  display: flex;
  justify-content: space-around;
  line-height: 50px;
  border-bottom: 1px solid #D2D2D2;
  cursor: pointer;
}
.TopUser span{
 display: inline-block;
 height: 50px;
}
.TopUser span:first-child {
  color: #FF5A5F;
}
.TopUser span:hover {
  color: #FF5A5F;
  border-bottom: 1px solid #FF5A5F;
}
.input input {
  width: 100%;
  height: 37px;
  line-height: 37px;
  border: none;
  padding-left: 34px;
}
.input img{
  position: absolute;
  width: 16px;
  height: 16px;
  left: 10px;
  top: 50%;
  transform: translate(0, -50%)
}
.Top .navText span {
  font-family: PingFangSC-Regular;
  padding-right: 10px;
  font-size: 16px;
  color: #666666;
  }
  .navText{
    padding-top: 6px;
  }
  .Top {
    background: #FFFFFF;
    padding-bottom: 14px;
    border-bottom: 1px solid #D2D2D2;
  }
.right a {
  cursor:pointer;
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #FF5A5F;
  position: absolute;
  left: 29px;
  top: 5px;
}
.right {
  position: relative;
}
.right i{
  display: block;
  height: 24px;
    background: url('../../../../assets/images/member/invitation@2x.png') no-repeat;
    background-size: 24px 24px;
    background-position: left;
}
.side {
  position: relative;
  background: #FFFFFF;
  box-shadow: 0 0 10px 0 rgba(0,0,0,0.10);
  border-radius: 4px;
}
.side .welcome {
  display: block;
  padding: 10px 20px;
  text-align: center;
  cursor:pointer;
  font-size: 14px;
  color: #FF5A5F;
}
.side img {
  height: 36px;
  width: 36px;
  vertical-align: middle;
  margin-right: 10px;
}
.side span {
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #999999;
}
.side ul li {
  display: block;
  width: 280px;
  height: 50px;
  padding-left: 20px;
  line-height: 50px;
}
.company{
  display: block;
  position: absolute;
  right: 50px;
  top: 10px;
  text-align: right;
}
.togger {
    height: 16px;
    width: 16px;
    position: absolute;
    right: 33px;
    top: 12px;
}
.togger img {
  height: 16px;
}
.togger img:last-child {
  right: -2px;
  top: 2px;
  position: absolute;
  display: none;
}
.togger img:focus+ img {
  display: block;
}
</style>
