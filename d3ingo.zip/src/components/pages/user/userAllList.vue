<template>
	<div>
    <navTitle></navTitle>
    <div class="container">
        <el-row :gutter="10">
          <el-col :span="isMob?24 : 6">
            <div class="input" @click="searchUsername">
              <input type="text" placeholder="搜索成员">
              <img src="../../../assets/images/member/search02@2x.png" alt="">
            </div>
            <div class="TopUser">
              <router-link :to="{name: 'userAllList'}"><span>成员</span></router-link> 
              <router-link :to="{name: 'userGroup'}"><span>群组</span></router-link>
            </div>
             <div class="Alluser">
                <ul>
                  <li class="All" @click="AlluserList">所有成员</li>
                  <!-- <li @click="newList">新加入的成员</li>
                  <li @click="NoList">未分配的成员</li>
                  <li @click="stop">常用成员</li> -->
                </ul>
              </div>
          </el-col>
          <el-col :span="isMob? 24: 18">
             <el-row>
        <el-col class="Top">
              <el-col :span="21" class="navText">
                <span>所有成员</span>
                <span>{{20}}</span>
              </el-col>
              <el-col :span="3" class="right">
                <i></i>
                <a @click="alick" class="welcome">邀请成员</a>
              <user :rand_string = "rand_string" :centerDialogVisible="isHide" @alick="alick"></user>
              </el-col>
        </el-col>
        <div class="toggeradmin">
          <el-col v-loading.body="isLoading">
            <el-table
              key="withdraw"
              :data="itemList"
              class="tableright"
              style="width: 100%;line-height: 50px;">
              <el-table-column
                min-width="100"
                class="tableuser"
                label="成员名称">
                <div slot-scope="userphoto" class="userphoto">
                  <img class="active" :src="eventUser.logo_url?eventUser.logo_url:require('assets/images/avatar_100.png')" alt="">
                  <span>{{userphoto.row.realname}}</span>
                </div>
              </el-table-column>
              <el-table-column
              class="tableposition"
                prop=""
                label="">
              </el-table-column>
              <el-table-column
              class="tableposition"
                prop=""
                label="">
              </el-table-column>
              <el-table-column
              class="tableposition"
                prop=""
                label="">
              </el-table-column>
              <el-table-column align="center" label="操作" class="tableoperation">
                <div slot-scope="props">
                  <span class="company">{{props.row.company_role_init}}</span>
                  <div class="togger">
                    <img @click="drop_down(props.$index)" src="../../../assets/images/member/small-arrow@2x.png" alt="">
                    <ul v-show="indexUser === props.$index && isOpen">
                      <li v-for="(d,index) in operation" :key="index"
                        @click="rootTogger(d.value, props.$index)">
                        <span>{{d.value}}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </el-table-column>
            </el-table>
          </el-col>
        </div>
      </el-row>
          </el-col>
      </el-row>
    </div>
	</div>
</template>
<script>
import navTitle from '@/components/pages/user/userTable/navTitle'
import user from '@/components/pages/user/Show/UserShow'
import api from '@/api/api'
export default {
  name: 'Search',
  data () {
    return {
      root: '',
      isOpen: false,
      isLoading: false,
      isHide: false,
      itemList: [],
      indexUser: -1,
      userAdmin: '',
      msgHide: false,
      // totalCount: 0,
      item: '',
      operation: [
        {id: 0, value: '管理人员'},
        {id: 1, value: '成员'},
        {id: 2, value: '常用成员'},
        {id: 3, value: '停用成员'}
      ],
      query: {
        page: 1,
        pageSize: 5,
        sort: 0
      },
      rand_string: ''
    }
  },
  components: {
    user,
    navTitle
  },
  methods: {
    drop_down(id) {
      // 角色：0.用户; 10.管理员admin； 15:管理员admin_plus 20：超级管理员root
      this.indexUser = id
      this.isOpen = !this.isOpen
    },
    rootTogger (ele, e) {
      this.isOpen = !this.isOpen
      this.itemList[e].company_role_init = ele
      // console.log(this.itemList)
      // 切换权限
      var userAdmin = parseInt([this.$store.state.event.user.role_id])
      if (userAdmin >= 10) {
        // console.log('管理员')
      } else {
        // console.log('成员')
      }
    },
    // 默认头像
    eventUser() {
      let user = this.$store.state.event.user
      if (user.avatar) {
        user.logo_url = user.avatar.logo
      } else {
        user.logo_url = null
      }
      return user
    },
    alick() {
      this.isHide = !this.isHide
      this.$http.get(api.inviteKey)
          .then((res) => {
            if (res.data.meta.status_code === 200) {
              console.log(res)
              this.rand_string = `${location.origin}/Invite/${res.data.data.rand_string}`
            } else {
              console.log(res.data.meta.message)
            }
          })
    },
    searchUsername () {
    },
    // newList () {
    //   console.log('新加入的成员')
    // },
    // NoList () {
    //   console.log('未分配的成员')
    // },
    // stop () {
    //   console.log('停用成员')
    // },
    AlluserList () {
      // console.log('所有成员')
    }
  },
  computed: {
    isMob() {
      return this.$store.state.event.isMob
    }
  },
  created () {
    const that = this
    that.$http.get(api.designMemberList)
        .then(function (response) {
          if (response.data.meta.status_code === 200) {
            that.itemList = response.data.data
            console.log(that.itemList)
            // that.query.totalCount = response.data.meta.pagination.total_pages
            for (let i of that.itemList) {
              if (i.company_role === 0) {
                i.company_role_init = '成员'
              } else if (i.company_role === 10) {
                i.company_role_init = '管理员'
              } else if (i.company_role === 20) {
                i.company_role_init = '超级管理员'
              }
            }
          }
        })
        .catch(function (error) {
          that.$message.error(error.message)
        })
  }
}
</script>

<style scoped>
.Alluser ul{
  font-size: 14px;
  cursor: pointer;
}
.Alluser ul li {
  height: 40px;
  line-height: 40px;
  padding-left: 10px;
}
.Alluser ul li:first-child {
  color:#FF5A5F;
  background: #F7F7F7;
}
.Alluser ul li:hover {
  color:#FF5A5F;
  background: #F7F7F7;
}
.input {
  position: relative;
  background: #FFFFFF;
  border: 1px solid #D2D2D2;
  border-radius: 2px;
  margin-bottom: 3px;
}
.TopUser {
  height: 50px;
  display: flex;
  justify-content: space-around;
  line-height: 50px;
  border-bottom: 1px solid #D2D2D2;
  cursor: pointer;
}
.TopUser span{
 display: inline-block;
 height: 50px;
}
.TopUser span:hover {
  color: #FF5A5F;
  border-bottom: 1px solid #FF5A5F;
}
.input input {
  width: 100%;
  height: 37px;
  line-height: 37px;
  border: none;
  padding-left: 34px;
}
.input img{
  position: absolute;
  width: 16px;
  height: 16px;
  left: 10px;
  top: 50%;
  transform: translate(0, -50%)
}
.Top .navText span {
  font-family: PingFangSC-Regular;
  padding-right: 10px;
  font-size: 16px;
  color: #666666;
  }
  .navText{
    padding-top: 6px;
  }
  .Top {
    background: #FFFFFF;
    padding-bottom: 14px;
    border-bottom: 1px solid #D2D2D2;
  }
.right a {
  cursor:pointer;
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #FF5A5F;
  position: absolute;
  left: 29px;
  top: 5px;
}
.right {
  position: relative;
}
.right i{
  display: block;
  height: 24px;
    background: url('../../../assets/images/member/invitation@2x.png') no-repeat;
    background-size: 24px 24px;
    background-position: left;
}
.side {
  position: relative;
  background: #FFFFFF;
  box-shadow: 0 0 10px 0 rgba(0,0,0,0.10);
  border-radius: 4px;
}
.side .welcome {
  display: block;
  padding: 10px 20px;
  text-align: center;
  cursor:pointer;
  font-size: 14px;
  color: #FF5A5F;
}
.side img {
  height: 36px;
  width: 36px;
  vertical-align: middle;
  margin-right: 10px;
}
.side span {
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #999999;
}
.side ul li {
  display: block;
  width: 280px;
  height: 50px;
  padding-left: 20px;
  line-height: 50px;
}
.company{
  display: block;
  position: absolute;
  right: 50px;
  top: 10px;
  text-align: right;
}
.togger {
    height: 16px;
    width: 16px;
    position: absolute;
    right: 33px;
    cursor: pointer;
    top: 12px;
}
.togger img {
  height: 16px;
}
.togger ul {
  width: 180px;
  border:1px solid #ccc;
  background: #FFFFFF;
  box-shadow: 0 0 10px 0 rgba(0,0,0,0.10);
  border-radius: 4px;
  position: absolute;
  z-index: 1000;
  right: -32px;
}
.togger ul li {
  height: 40px;
  text-align: center;
}
.togger ul li span {
  display: block;
}
.togger ul:focus li {
  background-color:#F7F7F7;
}
.userphoto img {
  border-radius: 50%;
  height: 36px;
  vertical-align: middle;
}
</style>
<style>
.toggeradmin {
  overflow: visible;
  z-index:inherit;
}
.tableuser {
  overflow: visible;
}
.toggeradmin .el-table tr {
  height: 50px;
  line-height:50px;
  overflow: visible;
}
.toggeradmin .tableposition {
  overflow: visible;
}
.toggeradmin .el-table td, .toggeradmin .el-table th {
    height: 60px;
    line-height: 60px;
}
.toggeradmin .tableoperation {
  overflow: visible;
}
.toggeradmin .tableright {
  overflow: visible;
}
.toggeradmin .el-table .cell 
.toggeradmin .el-table__footer-wrapper 
.toggeradmin .el-table__header-wrapper
.toggeradmin .el-table__body-wrapper{
  overflow: visible;
}
.toggeradmin .el-table th{
  overflow: visible;
}
.toggeradmin .use.userphoto {
  overflow: visible;
}
.toggeradmin .el-table__body-wrapper{
  overflow: visible;
}
</style>
