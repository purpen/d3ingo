<template>
  <div class="container">
    <div class="nav-list">
      <div class="category-list" ref="categoryList" v-if="cateList.length">
        <router-link :to="{name: 'articleList'}">最新</router-link>
        <router-link :to="{name: 'articleList', query: {category_id: d.id}}" v-for="(d, index) in cateList"
                     :key="index">{{ d.name }}
        </router-link>
        <router-link :to="{name: 'subjectList'}" class="active">专题</router-link>
      </div>
    </div>

    <div class="case-list" v-loading.body="isLoading" ref="caseList">
      <el-row :gutter="20" class="anli-elrow">
        <el-col :xs="24" :sm="12" :md="12" :lg="12" v-for="(d, index) in itemList" :key="index">
          <el-card :body-style="{ padding: '0px' }" class="item">
            <div class="image-box">
              <a :href="d.url" :target="BMob ? '_self' : '_blank'">
                <img v-lazy="d.cover_url">
              </a>
            </div>
            <div class="content">
              <p class="title">
                <a :href="d.url">{{ d.title }}</a>
              </p>
              <div class="des">
                <p>{{ d.content }}</p>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <div class="blank20"></div>
  </div>
</template>

<script>
  import api from '@/api/api'
  export default {
    name: 'article_list',
    data() {
      return {
        cateList: [],
        itemList: [
          {
            id: 8,
            title: '2018 iF季 小米生态链企业 众生相',
            cover_url: require ('@/assets/images/subject/list_06.jpg'),
            url: '/subject/XiaoMiInterview',
            content: '2018年，iF设计大奖公布，小米生态链众多产品获奖，铟果作为太火鸟旗下专注设计驱动创新力的SaaS平台，借此契机，采访了小米生态链负责人刘德和生态链内数位企业家，希望从他们的故事中，找到获奖产品背后不为人知的细节。'
          },
          {
            id: 7,
            title: '羽泉二十周年巡回演唱会-IP衍生品招募',
            cover_url: require ('@/assets/images/subject/list_05.jpg'),
            url: '/subject/YuQuanGifts',
            content: '2017年底，内地知名唱作组合羽泉与京东金融结成战略合作伙伴，双方在组合成立20周年巡回演唱会期间，将以羽泉组合这一明星IP为核心，衍生系列创意创新活动，内容涵盖广泛产品，活动名称为“羽泉的礼物”。'
          },
          {
            id: 5,
            title: '轻创新⋅设计造物-再设计⋅消费升级创新产品征集',
            cover_url: require ('@/assets/images/subject/list_03.jpg'),
            url: '/subject/ProductRecruit',
            content: '2017年初，太火鸟与投资方罗莱生活、海泉基金、京东金融、麦顿资本、泰德资本以及创新工场、真格基金等战略合作方共同发起了名为 “智见未来-太火鸟AesTech联合加速计划”，希望能够将太火鸟在产品孵化方面的前瞻性与各资本方及平台、渠道方在创新产品研发、孵化、营销环节的势能最大限度发挥出来，促进设计相关产业发展，改善设计生态，惠及大众。'
          },
          {
            id: 6,
            title: '轻创新⋅设计造物-邀请加入铟果D³INGO活动招募',
            cover_url: require ('@/assets/images/subject/list_04.jpg'),
            url: '/subject/EnterpriseRecruit',
            content: '铟果D³INGO是太火鸟旗下的创新产品交易与SaaS分发平台，是高效线上设计交易服务平台及中国领先的创新产品策源地，围绕创新产品与设计交易，为相关参与方提供包括创新产品孵化、资金保障、流量支持、运营维护等相关服务与帮助。'
          },
          {
            id: 1,
            title: '浙江“传统产业设计再造”计划线上对接专区',
            cover_url: require ('@/assets/images/subject/list_01.jpg'),
            url: '/subject/zj',
            content: '浙江“传统产业设计再造”计划由浙江省工业设计协会联合相关高校、梦栖工业设计小镇和全省17个省级工业设计示范基地共同发起，由浙江省工业设计创新服务基地运营公司杭州合创共响工业设计管理有限公司负责执行。'
          },
          {
            id: 4,
            title: 'RCIP衍生创新峰会暨年度新品发布会',
            cover_url: require ('@/assets/images/subject/list_02.jpg'),
            url: '/subject/rcip',
            content: '这是一场IP生态集群的权威路演；也是众多创新设计机构以IP内容结合的发布盛典想要了解更多？'
          }
        ],
        category_id: 0,
        isLoading: false,
        query: {
          page: 1,
          pageSize: 3,
          totalCount: 0,
          sort: 1,
          type: 0,
          category_id: 0,

          test: null
        },
        test: ''
      }
    },
    methods: {},
    created: function () {
      const self = this
      // 分类列表
      self.$http.get (api.categoryList, {params: {page: 1, per_page: 4, type: 1, sort: 1}})
        .then (function (response) {
          if (response.data.meta.status_code === 200) {
            self.cateList = response.data.data
            self.$refs.caseList.style.marginTop = '0'
          }
        })
        .catch (function (error) {
          self.$message.error (error.message)
        })
    },
    computed: {
      BMob() {
        return this.$store.state.event.isMob
      }
    }
  }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .container h3 {
    font-size: 2rem;
    margin-bottom: 10px;
    }

  .category-list {
    padding-bottom: 10px;
    margin: 30px auto 10px auto;
    text-align: center;
    min-width: 100%;
    white-space: nowrap;
    overflow-x: auto;
    }

  .category-list a {
    font-size: 1.6rem;
    margin-right: 40px;
    color: #666666;
    }

  .category-list a:hover,
  .category-list a.active {
    color: #FF5A5F;
    }

  .case-list {
    min-height: 350px;
    margin-top: 66px;
    }

  .item {
    /* height: 460px; */
    margin: 10px auto;
    }

  .item img {
    width: 100%;
    }

  .image-box {
    /* height: 350px; */
    overflow: hidden;
    }

  .content {
    padding: 20px;
    }

  .content p.title {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    }

  .content a {
    color: #222222;
    font-size: 1.8rem;
    }

  .des {
    margin: 10px auto;
    color: #666666;
    font-size: 1.4rem;
    line-height: 1.5;
    height: 42px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    }

  @media screen and ( max-width: 480px) {
    .nav-list {
      margin-top: 16px;
      height: 18px;
      overflow: hidden;
      }

    .category-list {
      margin: 0 auto 16px;
      padding: 2px 0 18px 16px;
      white-space: nowrap;
      overflow-x: auto;
      }

    .category-list a {
      margin-right: 30px;
      }

    .content {
      padding: 15px;
      }
    }
</style>
